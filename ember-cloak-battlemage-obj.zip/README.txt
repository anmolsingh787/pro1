Mint OBJ conversion package

Open or import Ember-Cloak-Battlemage.obj. Keep the textures folder beside the OBJ file so materials can resolve their image files.
